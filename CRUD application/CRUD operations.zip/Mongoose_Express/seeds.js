const mongoose=require('mongoose');
const Product=require('./models/product');



mongoose.connect('mongodb://127.0.0.1:27017/farmStand')
.then(()=>{
    console.log("Mongo Connection open!!!")
})
.catch(err => {
    console.log("OH NO MONGO CONNECTION ERROR")
    console.log(err)
})
/*
const p=new Product({
    name:'Grapes',
    price:50,
    category:'fruit'
})
p.save()
.then(p =>{
    console.log(p)
})
*/

const seedProducts=[
    {
        name:'Milk',
        price:20,
        category:'dairy'
    },
    {
        name:'Chocolate',
        price:80,
        category:'dairy'
    },
    {
        name:'potato',
        price:30,
        category:'vegetable'
    },
    {
        name:'Garlic',
        price:50,
        category:'vegetable'
    },
    {
        name:'Apple',
        price:150,
        category:'fruit'
    },
    {
        name:'Mango',
        price:200,
        category:'fruit'
    }
]

Product.insertMany(seedProducts)
    .then(res =>{
        console.log(res)
    })
    .catch(e=>{
        console.log(e)
    })